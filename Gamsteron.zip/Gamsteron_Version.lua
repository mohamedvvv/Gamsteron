return {
Gamsteron_Activator=1.3,
Gamsteron_Arrays=1.3,
Gamsteron_Loader=2.4,
Gamsteron_ObjectManager=1.3,
Gamsteron_Orbwalker=1.4,
Gamsteron_Utilities=1.3,}