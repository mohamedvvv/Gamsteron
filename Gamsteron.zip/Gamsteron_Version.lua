return {
Gamsteron_Activator=1.2,
Gamsteron_Arrays=1.2,
Gamsteron_Loader=2.3,
Gamsteron_ObjectManager=1.2,
Gamsteron_Orbwalker=1.1,
Gamsteron_Utilities=1.2,}